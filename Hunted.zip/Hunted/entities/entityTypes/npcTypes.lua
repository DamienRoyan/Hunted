NPCtypes = {}

format = {
    name = "",
    --stats
    life = 0,
    speed = 0,
    immunityMax = 1,
    rotates = false,
    enemy = "",
    --melee
    melee = 0,
    --gun
    ammo = "",
    rate = 0,
    --ai
    ai = nil,
    aiRate = 0
}

eyeball = {
    name = "eyeball",
    --stats
    life = 2,
    speed = 1,
    immunityMax = 0,
    rotates = false,
    enemy = "player",
    --melee
    melee = 1,
    --gun
    ammo = "",
    rate = 0.5,
    --ai
    ai = Stalk(),
    aiRate = 0
}

ranger = {
    name = "ranger",
    --stats
    life = 2,
    speed = 1,
    immunityMax = 1,
    rotates = true,
    enemy = "player",
    --melee
    melee = 1,
    --gun
    ammo = "bile",
    rate = 3,
    --ai
    ai = Shooter(),
    aiRate = 0
}

jouster = {
    name = "jouster",
    --stats
    life = 2,
    speed = 1,
    immunityMax = 1,
    rotates = false,
    enemy = "player",
    --melee
    melee = 1,
    --gun
    ammo = "",
    rate = 3,
    --ai
    ai = Joust(),
    aiRate = 2
}

teleporter = {
    name = "teleporter",
    --stats
    life = 2,
    speed = 1,
    immunityMax = 2,
    rotates = false,
    enemy = "player",
    --melee
    melee = 1,
    --gun
    ammo = "",
    rate = 0,
    --ai
    ai = Teleporter(),
    aiRate = 5
}

bulletBoss = {
    name = "bulletBoss",
    --stat
    life = 20,
    speed = 1,
    immunityMax = 1,
    rotates = false,
    enemy = "player",
    --melee
    melee = 1,
    --gun
    ammo = "bolt",
    rate = 0.1,
    --ai
    ai = BulletBoss(),
    aiRate = 0
}

for i, t in ipairs({eyeball, ranger, jouster, teleporter, bulletBoss}) do
    table.insert(NPCtypes, t)
end

function getNPC(name)
    for i, t in ipairs(NPCtypes) do
        if t.name == name then
            return t
        end
    end
    print("No such npc of type: " .. name)
    return nil
end