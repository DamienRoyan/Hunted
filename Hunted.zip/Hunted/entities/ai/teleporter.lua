Teleporter = AI:extend()

function Teleporter:update(client, target)
    if distanceTo(client, target) > (10 * tileSize) and client.aiCool <= 0 then
        client.aiCool = client.aiRate
        Teleporter:teleport(client, target, 10)
    else
        Teleporter:stalk(client, target)
    end
end