Stalk = AI:extend()

function Stalk:update(client, target)
    Stalk:stalk(client, target)
end