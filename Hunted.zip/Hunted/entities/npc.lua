NPC = Object:extend()

function NPC:new(nx, ny, name)
    --basic data
    self.x = nx
    self.y = ny
    self.angle = 0
    self.aimAngle = self.angle

    self.width = 32
    self.height = 32
    self.color = {r = 1, g = 1, b = 1}

    --npc data
    --stats
    self.life = 0
    self.speed = 0
    self.immunityMax = 0
    self.immunity = 0
    self.rotates = false
    self.enemy = ""
    --melee
    self.melee = 0
    --guns
    self.ammo = ""
    self.rate = 0
    self.rateCool = 0
    --ai
    self.ai = nil
    self.aiCool = 0
    self.aiRate = 0
    --graphics
    self.sprite = nil

    attributes = getNPC(name)
    if attributes ~= nil then
        --stats
        self.life  = attributes.life
        self.speed = attributes.speed
        self.immunityMax = attributes.immunityMax
        self.rotates = attributes.rotates
        self.enemy   = getTarget(attributes.enemy)
        --melee
        self.melee = attributes.melee
        --guns
        self.ammo    = attributes.ammo
        self.rate    = attributes.rate
        --ai
        self.ai      = attributes.ai
        self.aiRate  = attributes.aiRate
        --graphics
        self.sprite  = love.graphics.newImage("res/images/" .. name ..".png")
    end
end

function NPC:update()
    if self.ai ~= nil then
        self.ai:update(self, self.enemy)
    end
    
    if self.rateCool > 0 then
        self.rateCool = self.rateCool - gdt
    end
    if self.aiCool > 0 then
        self.aiCool = self.aiCool - gdt
    end
    if self.immunity > 0 then
        self.immunity = self.immunity - gdt
    end
    
    self:handleMelee()
end

function NPC:handleMelee()
    if collide(self, self.enemy) then
        applyDamage(self.enemy, self.melee)
    end
end

function NPC:draw()
    if self.rotates then
        drawWithAngle(self)
    else
        draw(self)
    end
end