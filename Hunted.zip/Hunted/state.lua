require "states/menuState"
require "states/gameState"
require "states/overState"

states = {"menu", "game", "over"}

currentN = 1
current = states[currentN]

function switchState()
    currentN = currentN + 1
    if currentN > #states then
        currentN = 1
    end

    current = states[currentN]

    if currentN == 2 then
        resetGame()
    end
end

function stateUpdate()
    if current == "menu" then
        updateMenu()
    elseif current == "game" then
        updateGame()
    elseif current == "over" then
        updateGameOver()
    end
end

function drawState()
    if current == "menu" then
        drawMenu()
    elseif current == "game" then
        drawGame()
    elseif current == "over" then
        drawGameOver()
    end
end