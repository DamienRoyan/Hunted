function updateGameOver()
    if love.keyboard.isDown("space") then
        switchState()
    end

    if love.keyboard.isDown("escape") then
        love.event.quit()
    end
end

function drawGameOver()
    love.graphics.translate(screenWidth/2, 0)
    love.graphics.setNewFont(30)
    love.graphics.setColor(1, 0, 0)

    local y = 200

    if win then
        drawBigText("You Survived", y)
    else
        drawBigText("You were hunted down", y)
    end
    y = y + 200
    drawText(string.format("Waves survived: %d", level - 1), y)
    y = y + 50
    drawText(string.format("Enemies killed: %d", kills),     y)
    y = y + 100
    drawText("Press Space to return to menu", y)
    y = y + 50
    drawText("Press Esc to quit", y)
end