function drawText(text, y)
    local width = love.graphics.getFont():getWidth(text)
    love.graphics.print(text, -width/2, y)
end

function drawBigText(text, y)
    drawTextOfSize(text, y, 80)
end

function drawTextOfSize(text, y, size)
    love.graphics.setNewFont(size)
    local width = love.graphics.getFont():getWidth(text)
    love.graphics.print(text, -width/2, y)
    love.graphics.setNewFont(defaultFontSize)
end