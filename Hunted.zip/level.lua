levels = {}

maxHealth = 10
health = maxHealth

format = {
    {name = "", num = 0},
    {name = "", num = 0},
    {name = "", num = 0}
}

lvl1 = {
    {name = "eyeball", num = 10}
}

lvl2 = {
    {name = "eyeball", num = 20}
}

lvl3 = {
    {name = "eyeball", num = 15},
    {name = "ranger",  num = 5}
}

lvl4 = {
    {name = "eyeball", num = 10},
    {name = "ranger",  num = 10}
}

lvl5 = {
    {name = "ranger", num = 20}
}

lvl6 = {
    {name = "eyeball", num = 10},
    {name = "ranger",  num = 5},
    {name = "jouster", num = 5}
}

lvl7 = {
    {name = "ranger",     num = 10},
    {name = "jouster",    num = 5},
    {name = "teleporter", num = 5}
}

lvl8 = {
    {name = "jouster",    num = 20},
    {name = "teleporter", num = 10}
}

lvl9 = {
    {name = "eyeball",    num = 20},
    {name = "ranger",     num = 20},
    {name = "jouster",    num = 20},
    {name = "teleporter", num = 20},
}

lvl10 = {
    {name = "bulletboss", num = 1},
}

for i, l in ipairs({lvl1, lvl2, lvl3, lvl4, lvl5, lvl6, lvl7, lvl8, lvl9, lvl10}) do
    table.insert(levels, l)
end

--helper function--
function copyTable(original, new)
    --for every level in the table
    for i, l in ipairs(original) do
        local levelTable = {}
        --for every roster in the level
        for i, r in ipairs(l) do
            roster = {name = r.name, num = r.num}
            table.insert(levelTable, roster)
        end
        table.insert(new, levelTable)
    end
end

--make copy
levelsCopy = {}
copyTable(levels, levelsCopy)

function resetLevel()
    levels = {}
    copyTable(levelsCopy, levels)
end

function getSpawn(level)
    l = levels[level]
    r = love.math.random(#l)
    roster = l[r]

    if roster ~= nil then
        roster.num = roster.num - 1

        --print(string.format("r: %d\tn: %d", r, roster.num))

        --if no more monsters of this type
        if roster.num <= 0 then
            table.remove(l, r)
        end

        return roster.name
    else
        return false
    end
end