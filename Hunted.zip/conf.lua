function love.conf(t)
    t.window.title = "Hunted"
    t.window.icon = "res/images/wizard.png"
    t.window.fullscreen = true
end