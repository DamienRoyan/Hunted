BulletTypes = {}

format = {
    name = "",
    damage = 0,
    speed = 0,
    penetration = 0,
    rotates = false
}

orb = {
    name = "orb",
    damage = 1,
    speed = 2,
    penetration = 0,
    rotates = false
}

bolt = {
    name = "bolt",
    damage = 1,
    speed = 4,
    penetration = 1,
    rotates = true
}

bile = {
    name = "bile",
    damage = 1,
    speed = 3,
    penetration = 0,
    rotates = true
}

arrow = {
    name = "arrow",
    damage = 1,
    speed = 3,
    penetration = 0,
    rotates = true
}

for i, t in ipairs({orb, bolt, bile, arrow}) do
    table.insert(BulletTypes, t)
end

function getBullet(name)
    for i, t in ipairs(BulletTypes) do
        if t.name == name then
            return t
        end
    end
    print("No such bullet of type: " .. name)
    return nil
end