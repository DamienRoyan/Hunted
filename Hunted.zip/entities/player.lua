Player = NPC:extend()

function Player:new()
    --basic data
    self.name = "player"
    self.x = 0
    self.y = 0
    self.speed = 3
    
    --physics
    self.angle = 0
    self.vX = 0
    self.vY = 0

    --body physics
    self.width = 32
    self.height = 32

    --graphics
    self.color = {r = 1, g = 1, b = 1}
    self.sprite = love.graphics.newImage("res/images/wizard.png")

    --player stats
    self.life = 5
    self.maxLife = 5
    self.immunityMax = 1
    self.immunity = 0

    --gun
    self.aimAngle = 0
    self.rate = 0.5
    self.rateCool = 0
    self.ammo = "orb"
end

function Player:update()
    self:control()
    self:gun()

    --player is not affected by time modulation
    local pdt = gdt / dtMult

    if self.immunity > 0 then
        self.immunity = self.immunity - pdt
    end
    if self.rateCool > 0 then
        self.rateCool = self.rateCool - pdt
    end
end

function Player:control()
    self:movement()
end

function Player:movement()
    local x = 0
    local y = 0

    if love.keyboard.isDown("a") then
        x = x - 1
        self.angle = math.pi
    end
    if love.keyboard.isDown("d") then
        x = x + 1
        self.angle = 0
    end
    if love.keyboard.isDown("w") then
        y = y - 1
    end
    if love.keyboard.isDown("s") then
        y = y + 1
    end

    x = x * self.speed
    y = y * self.speed

    moveBy(self, x, y)
end

function Player:gun()
    self:aim()

    shoot(self, "enemy", true)
end

function Player:aim()
    --find nearest enemy
    local nearest = nil
    local nearDist = 100000

    for i = 1, #enemies do
        local e = enemies[i]
        dist = distanceTo(self, e)
        if dist < nearDist then
            nearest  = e
            nearDist = dist
        end
    end

    self.aimAngle = getAngle(self, nearest)
end

function Player:draw()
    draw(self)
end