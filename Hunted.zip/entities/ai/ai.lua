AI = Object:extend()

function AI:new()
end

function AI:update(client, target)
    print("ai")
end

function AI:stalk(client, target)
    moveTo(client, target)
end

function AI:shootAt(client, target)
    rotateTo(client, target)
    client.aimAngle = client.angle
    shoot(client, target, true)
end

function AI:shootFrenzy(client, target, rays)
    local rad = (2 * math.pi)/rays
    rotateTo(client, target)
    client.aimAngle = client.angle

    if client.rateCool <= 0 then
        for i = 1, rays do
            shootAnyway(client, target)
            client.aimAngle = client.aimAngle + rad
        end
        shoot(client, target, true)
    end
end

function AI:rush(client, target, speed)
    moveAtSpeed(client, client.speed * speed)
end

function AI:teleport(client, target, proximity)
    local newPos = positionAround(target, proximity * tileSize)
    client.x = newPos.px
    client.y = newPos.py
end