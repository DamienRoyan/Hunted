Joust = AI:extend()

function Joust:update(client, target)
    ::recheck::

    if client.aiCool > 0 then
        Joust:rush(client, target, 7)
    else
        if distanceTo(client, target) > (10 * tileSize) then
            Joust:stalk(client, target)
        else
            client.aiCool = 2
            goto recheck
        end
    end
end