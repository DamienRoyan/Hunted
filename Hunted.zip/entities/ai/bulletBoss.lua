BulletBoss = AI:extend()

function BulletBoss:update(client, target)
    if distanceTo(client, target) > (10 * tileSize) then
        BulletBoss:stalk(client, target)
    else
        BulletBoss:shootFrenzy(client, target, 20)
    end
end