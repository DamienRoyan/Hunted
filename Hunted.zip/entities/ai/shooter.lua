Shooter = AI:extend()

function Shooter:update(client, target)
    if distanceTo(client, target) <= (7 * tileSize) then
        Shooter:shootAt(client, target)
    else
        Shooter:stalk(client, target)
    end
end