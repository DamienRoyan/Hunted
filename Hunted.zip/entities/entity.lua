--helpers
function collide(client, target)
    if  client.x + client.width/2  > target.x
    and client.y + client.height/2 > target.y
    and client.x < target.x + target.width/2
    and client.y < target.y + target.height/2 then
        return true
    else
        return false
    end
end

function getTarget(target)
    if type(target) ~= "string" or target == "enemy" then
        return target
    else
        if target == "player" then
            return player
        end
    end
end

function shoot(client, target, cool)
    if target == "enemy" and #enemies == 0 then
        return
    elseif cool == false then
        table.insert(bullets, Bullet(client.ammo, client, target))
    elseif client.rateCool <= 0 then
        client.rateCool = client.rate
        table.insert(bullets, Bullet(client.ammo, client, target))
    end
end

function shootAnyway(client, target)
    if target == "enemy" and #enemies == 0 then
        return
    else
        client.rateCool = client.rate
        table.insert(bullets, Bullet(client.ammo, client, target))
    end
end

--getters
function getPosition(target)
    return target.x, target.y
end

function distanceTo(client, target)
    if target ~= nil then
        local tx, ty = getPosition(target)
        local dx = client.x - target.x
        local dy = client.y - target.y

        return math.sqrt((dx ^ 2) + (dy ^ 2))
    else
        return 0
    end
end

function getAngle(client, target)
    if target ~= nil then
        local x, y = getPosition(target)

        return math.atan2(target.y - client.y, target.x - client.x)
    else
        return 0
    end
end

function positionAround(target, radius)
    local angle = math.random(0, 2 * math.pi)
    local x = target.x + (radius * math.cos(angle))
    local y = target.y + (radius * math.sin(angle))

    return {px = x, py = y}
end


--setters
function applyDamage(target, damage)
    if target.immunity > 0 then
        return
    else
        target.immunity = target.immunityMax
    end

    target.life = target.life - damage

    --if bullet or melee
    if damage > 0 then
        local h = hit:clone()
        h:play()
    else    --health pickup
        if target.life > target.maxLife then
            target.life = target.maxLife
        end
    end
end

function rotateTo(client, target)
    client.angle = getAngle(client, target)
end

function move(client)
    local speed = client.speed * 100 * gdt

    moveAtSpeed(client, speed)
end

function moveAtSpeed(client, speed)
    cos = math.cos(client.angle)
    sin = math.sin(client.angle)

    client.x = client.x + (speed * cos)
    client.y = client.y + (speed * sin)
end

function moveBy(client, x, y)
    client.x = client.x + x
    client.y = client.y + y
end

function moveTo(client, target)
    rotateTo(client, target)
    move(client)
end


--graphics
function draw(client)
    local direction = 0
    if math.cos(client.angle) < 0 then
        direction = -1
    else
        direction = 1
    end

    love.graphics.setColor(
        client.color.r,
        client.color.g,
        client.color.b
    )
    love.graphics.draw(
        client.sprite,
        client.x, client.y,
        0, direction * tileScaleX, tileScaleY,
        client.sprite:getWidth()/2, client.sprite:getHeight()/2
    )
end

function drawWithAngle(client)
    love.graphics.setColor(
        client.color.r,
        client.color.g,
        client.color.b
    )
    love.graphics.draw(
        client.sprite,
        client.x, client.y,
        client.angle, tileScaleX, tileScaleY,
        client.sprite:getWidth()/2, client.sprite:getHeight()/2
    )
end