Bullet = Object:extend()

function Bullet:new(name, client, target)
    --parameter checking
    if client == nil then
        print("Bullet nil client")
    end
    if target == nil then
        print("Bullet nil target")
    end

    --basic data
    self.x = client.x
    self.y = client.y
    self.angle = client.aimAngle

    self.client = client
    self.target = target

    self.width = 32
    self.height = 32
    self.decay = 5
    self.color = {r = 1, g = 1, b = 1}

    
    --bullet data
    self.damage = 0
    self.speed = 0
    self.rotates = false
    self.penetration = 0
    self.sprite = nil
    
    attributes = getBullet(name)
    if attributes ~= nil then
        self.damage  = attributes.damage
        self.speed   = attributes.speed
        self.rotates = attributes.rotates
        self.penetration = attributes.penetration
        self.sprite = love.graphics.newImage("res/images/".. attributes.name .. ".png")
    end
end

function Bullet:update()
    --vague target
    if self.target == "enemy" then
        --look through all enemies for possible hits
        for i,t in ipairs(enemies) do
            if collide(self, t) then
                self:hit(t)
                break
            end
        end
    --specific target
    else
        if collide(self, self.target) then
            self:hit(self.target)
        end
    end

    --make bullet despawn after some distance
    self.decay = self.decay - gdt
    if self.decay <= 0 then
        self.used = true
    end

    if self.client == player then
        moveAtSpeed(self, self.speed)
    else
        move(self)
    end
end

function Bullet:hit(target)
    applyDamage(target, self.damage)

    if self.penetration ~= "inf" then
        if self.penetration > 0 then
            self.penetration = self.penetration - 1
        else
            self.used = true
        end
    end
end

function Bullet:draw()
    if self.rotates then
        drawWithAngle(self)
    else
        love.graphics.draw(
        self.sprite,
        self.x, self.y,
        self.angle, tileScaleX, tileScaleY,
        self.width/2, self.height/2
        )
    end
end