function updateGameOver()
    if love.keyboard.isDown("space") then
        switchState()
    end

    if love.keyboard.isDown("escape") then
        love.event.quit()
    end
end

function drawGameOver()
    love.graphics.translate(screenWidth/2, 0)
    love.graphics.setNewFont(30)
    love.graphics.setColor(1, 0, 0)

    local y = (100 * tileScaleY)

    if win then
        drawBigText("You Survived", y)
    else
        drawBigText("You were hunted down", y)
    end
    y = y + (100 * tileScaleY)
    drawText(string.format("Waves survived: %d", level - 1), y)
    y = y + (50 * tileScaleY)
    drawText(string.format("Enemies killed: %d", kills),     y)
    y = y + (100 * tileScaleY)
    drawText("Press Space to return to menu", y)
    y = y + (50 * tileScaleY)
    drawText("Press Esc to quit", y)
end