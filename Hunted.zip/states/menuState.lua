title = "Hunted"

--title
love.graphics.setNewFont(100)
width = love.graphics.getFont():getWidth(title)
love.graphics.setNewFont(defaultFontSize)

--buttons
buttons = {}
offsetX = 100 * tileScaleX
offsetY = 0 * tileScaleY
buttonFontSize = defaultFontSize * 2

function createButton(x, y, width, height, text, action)
    x = x - width/2 - offsetX/2
    y = y - height/2 - offsetY/2
    width = width + offsetX
    height = height + offsetY

    table.insert(buttons, {bx = x, by = y, bw = width, bh = height, bt = text, ba = action})
end

--initialise buttons
love.graphics.setNewFont(buttonFontSize)
--start
createButton(screenWidth/2, screenHeight/2, 
            love.graphics.getFont():getWidth("Start"), love.graphics.getFont():getHeight("Start"),
            "Start", "start")
--quit
createButton(screenWidth/2, screenHeight/2 + 100, 
            love.graphics.getFont():getWidth("Quit"), love.graphics.getFont():getHeight("Quit"),
            "Quit", "quit")
love.graphics.setNewFont(defaultFontSize)

--update
function updateMenu()
    checkButtons()
end

function checkButtons()
    local mouseX = love.mouse.getX()
    local mouseY = love.mouse.getY()

    for i, b in ipairs(buttons) do
        if mouseX > b.bx and mouseY > b.by and
           mouseX < b.bx + b.bw and mouseY < b.by + b.bh and love.mouse.isDown(1) then
            buttonAction(b.ba)
        end
    end
end

function buttonAction(action)
    if action == "start" then
        switchState()
    elseif action == "quit" then
        love.event.quit()
    end
end

--graphics
function drawMenu()
    love.graphics.setColor(1, 0, 0)

    drawTitle()
    drawButtons()
end

function drawTitle()
    love.graphics.push()
    love.graphics.translate(screenWidth/2, 0)
    drawTextOfSize(title, 100, 120)
    love.graphics.pop()
end

function drawButtons()
    love.graphics.setNewFont(buttonFontSize)
    for i, b in ipairs(buttons) do
        love.graphics.setColor(1, 0, 0)
        love.graphics.rectangle("fill", b.bx, b.by, b.bw, b.bh)
        love.graphics.setColor(0, 0, 0)
        love.graphics.print(b.bt, b.bx + offsetX/2, b.by + offsetY/2)
    end
    love.graphics.setNewFont(defaultFontSize)
end