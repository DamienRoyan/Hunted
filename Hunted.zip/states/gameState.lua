--spawning
player = Player()

enemies = {}

--bullets
bullets = {}

--all tables
tables = {}
table.insert(tables, enemies)
table.insert(tables, bullets)

--game stats
spawnDelay = 1
level = 1
kills = 0
win = false

function resetGame()
    player = Player()
    enemies = {}
    bullets = {}
    tables = {}
    table.insert(tables, enemies)
    table.insert(tables, bullets)
    spawnDelay = 1
    level = 1
    kills = 0
    win = false
    resetLevel()
end

--update
function updateGame()
    if player.life <= 0 then
        switchState()
    end

    --update entities
    player:update()
    for t = 1, #tables do
        for i, e in ipairs(tables[t]) do
            e:update()
        end
    end

    spawnDelay = spawnDelay - gdt
    if spawnDelay <= 0 then
        spawnDelay = 2
        spawn()
    end

    checkDeath()
end

function spawn()
    ::spawn::
    if level > 10 then
        print("win")
        win = true
        switchState()
        return
    end

    local name = getSpawn(level)
    if name == false then   --spawning over
        if #enemies == 0 then --level over
            level = level + 1
            goto spawn
        end
        return
    end

    local location = spawnLocation()

    table.insert(enemies, NPC(location[1], location[2], name))
end

function spawnLocation()
    local extra = 100
    local orientation = love.math.random(0, 1)
    local side = love.math.random(0, 1)

    --x oriented
    if orientation == 0 then
        return {love.math.random(player.x - screenWidth/2 - extra,  player.x + screenWidth/2) + extra,
               (player.y - screenHeight/2) + side * screenHeight}
    --y oriented
    else
        return {(player.x - screenWidth/2) + side * screenWidth,
               love.math.random(player.x - screenHeight/2 - extra,  player.x + screenHeight/2) + extra}
    end
end

function checkDeath()
    if #enemies > 0 then
        for i = #enemies, 1, -1 do
            if enemies[i].life <= 0 then
                table.remove(enemies, i)
                kills = kills + 1
                local d = death:clone()
                d:play()
            end
        end
    end

    if #bullets > 0 then
        for i = #bullets, 1, -1 do
            if bullets[i].used then
                table.remove(bullets, i)
            end
        end
    end
end

--graphics
function drawGame()
    love.graphics.push()

    --entities
    love.graphics.translate(screenWidth/2 - player.x, screenHeight/2 - player.y)
    
    color = {1, 1, 1}
    drawAura(color, player)
    player:draw()

    
    color = {1, 0, 0}
    for i, e in ipairs(enemies) do
        drawAura(color, e)
        e:draw()
    end

    for i, b in ipairs(bullets) do
        b:draw()
    end

    love.graphics.pop()

    --ui
    drawUI()
end

function drawAura(color, e)
    love.graphics.setColor(color[1], color[2], color[3], 0.07)
    love.graphics.circle("fill", e.x, e.y, 2 * tileSize)
    love.graphics.circle("fill", e.x, e.y, 1.5 * tileSize)
    love.graphics.circle("fill", e.x, e.y, 1 * tileSize)
    love.graphics.setColor(1, 1, 1)
end

function drawUI()
    --health bar
    love.graphics.setColor(1,0,0)
    local heartX = 20
    local heartY = 30
    for i = 0, player.life - 1 do
        love.graphics.rectangle("fill", (i * heartX) * tileScaleX, 0, (heartX - 5) * tileScaleX, heartY * tileScaleY)
    end
    love.graphics.setColor(1,1,1)

    --waves
    love.graphics.translate(screenWidth/2, 0)
    drawText(string.format("Wave %d", level))
end