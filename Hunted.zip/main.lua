function love.load()
    --window setup
    love.window.setFullscreen(true)

    --global variables
    screenWidth  = love.graphics.getWidth()
    screenHeight = love.graphics.getHeight()
    tileSize = 32
    tileScaleX = screenWidth/800
    tileScaleY = screenHeight/600
    tileScaleX, tileScaleY = math.min(tileScaleX, tileScaleY), math.min(tileScaleX, tileScaleY)
    defaultFontSize = 20 * tileScaleX
    gdt = 0
    dtMult = 1

    --imports
    Object = require "classic"
    require "libraries/AILibrary"
    require "libraries/entityLibrary"
    require "states/text"
    require "level"
    require "state"
    

    --preload resources
    --tiles
    tile = love.graphics.newImage("res/images/tile.png")
    --audio
    ambience = love.audio.newSource("res/music/ambience.wav", "stream")
    hit = love.audio.newSource("res/music/hit.wav", "static")
    death = love.audio.newSource("res/music/death.wav", "static")
    ambience:setLooping(true)
    ambience:play()
end

function love.update(dt)
    gdt = (dt * dtMult)
    stateUpdate()
end

function love.draw()
    love.graphics.setNewFont(defaultFontSize)
    --background
    love.graphics.setColor(1, 1, 1)
    for y=-2, screenHeight/tileSize + 1 do
        for x=-2, screenWidth/tileSize + 1 do
            love.graphics.draw(tile, x * tileSize, y * tileSize, 0, tileScaleX, tileScaleY)
        end
    end

    drawState()
end